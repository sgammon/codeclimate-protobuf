"""
codeclimate-test-reporter
"""

import os

__author__ = "Code Climate"
__version__ = open(os.path.join(os.path.dirname(__file__), "VERSION")).read().strip()
__license__ = "MIT"
